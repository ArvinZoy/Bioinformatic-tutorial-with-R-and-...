setwd("")

library("genetics")
for(i in 1:ncol(SNPdata)){
 SNPdata[,i]<-as.genotype(SNPdata[,i])
}
LDheatmap(SNPdata, SNPpos,color = grey.colors(20))

color.rgb <- colorRampPalette(rev(c("white","red")),space="rgb")
## ����������ƽ��ͼ
names <- c("rs1111183", "rs2237789", "rs2299531")
LDheatmap(SNPdata, SNPpos,
         color=color.rgb(20),
         title = "DEU Pairwise LD",
         SNP.name=names,flip=TRUE)

library(grid)
grid.edit(gPath("ldheatmap", "geneMap","SNPnames"),
   gp = gpar(col="black",lwd = 1,cex=0.7))


 myLDplot=function(file,LD=F,out=F){
  library("genetics")
  library("LDheatmap")
  data=read.table(file,head=T,com="",sep="\t",row=1,na.string="--")
  gene=data[,11:ncol(data)]
  gene=data.frame(t(gene))
  gty=makeGenotypes(gene,sep="")
 
  rgb.palette <- colorRampPalette(rev(c("yellow","white" ,"red")), space = "rgb")
  png(file="3.png",res=300,width=2000,height=2000)
  myld=LDheatmap(gty,genetic.distances=data$pos,flip=T,add.map=T,color=rgb.palette(18),pop=T)
  dev.off()
 
  if(LD){
  write.table(myld$LDmatrix,file=sub(".txt","_LD.txt",file),sep="\t",quote=F)
  }
 
  if(out){ myld}else{NULL}
 
}
 
#example
myLDplot("MADS0.01.txt",LD=T)

